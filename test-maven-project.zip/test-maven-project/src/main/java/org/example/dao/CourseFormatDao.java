package org.example.dao;

import org.example.models.Group;

public interface CourseFormatDao extends CrudDao<Group>{
}
