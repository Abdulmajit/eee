package org.example.dao;

import org.example.models.Group;

public interface CourseDao extends CrudDao<Group>{
}
