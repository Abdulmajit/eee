package org.example.dao;

import org.example.models.Group;

public interface MentorDao extends CrudDao<Group>{
}
