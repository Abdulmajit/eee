package org.example.dao;

import org.example.models.Group;

public interface AddressDao extends CrudDao<Group>{
}
