package org.example.dao;

import org.example.models.Group;

public interface GroupDao extends CrudDao<Group>{
}
