package org.example.dao;

import org.example.models.Group;

public interface ManagerDao extends CrudDao<Group>{
}
