package org.example.dao.impl;

public class ManagerDaoImpl {
}
