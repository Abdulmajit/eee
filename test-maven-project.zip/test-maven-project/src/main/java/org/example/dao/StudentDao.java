package org.example.dao;

import org.example.models.Group;

public interface StudentDao extends CrudDao<Group>{
}
